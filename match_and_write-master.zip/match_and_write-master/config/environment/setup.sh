#!/bin/bash -i

git clone https://github.com/alvi2496/pyenvilder.git ~/pyenvilder
cd ~/pyenvilder
./build.sh -v 3.6.0 -n match_and_write
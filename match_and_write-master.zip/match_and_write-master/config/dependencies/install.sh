#! /bin/bash

pip install pandas
pip install matplotlib
pip install -U scikit-learn
pip3 install xgboost
pip install -U textblob
pip install --upgrade tensorflow
pip install keras
pip install -U nltk
pip3 install PTable
#!/bin/bash -i

source activate.sh
